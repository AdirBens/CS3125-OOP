﻿using System;


namespace ConsoleUI
{
    internal class BackSignalRaiseException : Exception
    {
        public BackSignalRaiseException() { }
    }
}
