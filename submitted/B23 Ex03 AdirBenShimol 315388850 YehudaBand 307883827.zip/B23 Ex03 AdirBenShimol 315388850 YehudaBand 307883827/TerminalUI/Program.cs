﻿
namespace ConsoleUI
{
    public class Program
    {
        public static void Main()
        {
            TerminalUserInterface userInterface = new TerminalUserInterface();
            userInterface.RunProgram();
        }
    }
}
