﻿using ConsoleUI;

namespace TerminalUI
{
    public class Program
    {
        public static void Main()
        {
            TerminalUserInterface userInterface = new TerminalUserInterface();
            userInterface.RunProgram();
        }
    }
}
